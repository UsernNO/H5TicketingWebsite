const base = {
    get() {
        return {
            url : "http://localhost:8080/ychpw/",
            name: "ychpw",
            // 退出到首页链接
            indexUrl: 'http://localhost:8080/ychpw/front/index.html'
        };
    },
    getProjectName(){
        return {
            projectName: "演唱会购票系统"
        } 
    }
}
export default base
