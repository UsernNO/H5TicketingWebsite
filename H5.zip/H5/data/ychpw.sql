/*
 Navicat Premium Data Transfer

 Source Server         : local
 Source Server Type    : MySQL
 Source Server Version : 50726 (5.7.26)
 Source Host           : localhost:3306
 Source Schema         : ychpw

 Target Server Type    : MySQL
 Target Server Version : 50726 (5.7.26)
 File Encoding         : 65001

 Date: 24/04/2024 16:27:49
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for chat
-- ----------------------------
DROP TABLE IF EXISTS `chat`;
CREATE TABLE `chat`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `userid` bigint(20) NOT NULL COMMENT '用户id',
  `adminid` bigint(20) NULL DEFAULT NULL COMMENT '管理员id',
  `ask` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '提问',
  `reply` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '回复',
  `isreply` int(11) NULL DEFAULT NULL COMMENT '是否回复',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '客服聊天表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of chat
-- ----------------------------

-- ----------------------------
-- Table structure for config
-- ----------------------------
DROP TABLE IF EXISTS `config`;
CREATE TABLE `config`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '配置参数名称',
  `value` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '配置参数值',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '配置文件' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of config
-- ----------------------------
INSERT INTO `config` VALUES (1, 'picture1', 'http://localhost:8080/ychpw/upload/picture1.jpg');
INSERT INTO `config` VALUES (2, 'picture2', 'http://localhost:8080/ychpw/upload/picture2.jpg');
INSERT INTO `config` VALUES (3, 'picture3', 'http://localhost:8080/ychpw/upload/picture3.jpg');
INSERT INTO `config` VALUES (6, 'homepage', NULL);

-- ----------------------------
-- Table structure for fenlei
-- ----------------------------
DROP TABLE IF EXISTS `fenlei`;
CREATE TABLE `fenlei`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `fenlei` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '分类',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 27 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '分类' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of fenlei
-- ----------------------------
INSERT INTO `fenlei` VALUES (21, '2021-04-24 14:22:42', '内娱');
INSERT INTO `fenlei` VALUES (22, '2021-04-24 14:22:42', '港澳台');
INSERT INTO `fenlei` VALUES (23, '2021-04-24 14:22:42', '欧洲');
INSERT INTO `fenlei` VALUES (24, '2021-04-24 14:22:42', '美国');
INSERT INTO `fenlei` VALUES (25, '2021-04-24 14:22:42', '日本');
INSERT INTO `fenlei` VALUES (26, '2021-04-24 14:22:42', '拉美');

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `orderid` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '订单编号',
  `tablename` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 'yanchanghui' COMMENT '商品表名',
  `userid` bigint(20) NOT NULL COMMENT '用户id',
  `goodid` bigint(20) NOT NULL COMMENT '商品id',
  `goodname` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商品名称',
  `picture` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商品图片',
  `buynumber` int(11) NOT NULL COMMENT '购买数量',
  `price` float NOT NULL DEFAULT 0 COMMENT '价格/积分',
  `discountprice` float NULL DEFAULT 0 COMMENT '折扣价格',
  `total` float NOT NULL DEFAULT 0 COMMENT '总价格/总积分',
  `discounttotal` float NULL DEFAULT 0 COMMENT '折扣总价格',
  `type` int(11) NULL DEFAULT 1 COMMENT '支付类型',
  `status` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '状态',
  `address` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '地址',
  `tel` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '电话',
  `consignee` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '收货人',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `orderid`(`orderid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1713919527984 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '订单' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES (1713919527983, '2024-04-24 08:45:27', '20244248452744008194', 'yanchanghui', 1713919501794, 31, 'Taylor Swift Reputation 世界演唱会（南宁站）', 'http://localhost:8080/ychpw/upload/yanchanghui_haibao1.jpg', 2, 99.9, 99.9, 199.8, 199.8, 1, '已完成', '2,4', NULL, NULL);

-- ----------------------------
-- Table structure for token
-- ----------------------------
DROP TABLE IF EXISTS `token`;
CREATE TABLE `token`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `userid` bigint(20) NOT NULL COMMENT '用户id',
  `username` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户名',
  `tablename` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '表名',
  `role` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '角色',
  `token` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '密码',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '新增时间',
  `expiratedtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '过期时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'token表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of token
-- ----------------------------
INSERT INTO `token` VALUES (1, 1713919501794, 'oyo775881', 'yonghu', '用户', '343trj8nqvqux97b5w0cj9b2k4fzwek6', '2024-04-24 08:45:10', '2024-04-24 17:20:45');
INSERT INTO `token` VALUES (2, 1, 'admin', 'users', '管理员', 'dqq4b5ddj5kvpg8v3iw5pn8tuglx403y', '2024-04-24 10:32:01', '2024-04-24 11:32:01');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `username` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户名',
  `password` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '密码',
  `role` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '管理员' COMMENT '角色',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '新增时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (1, 'admin', '123456', '管理员', '2021-04-24 14:22:42');

-- ----------------------------
-- Table structure for yanchanghui
-- ----------------------------
DROP TABLE IF EXISTS `yanchanghui`;
CREATE TABLE `yanchanghui`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `mingcheng` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '名称',
  `haibao` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '海报',
  `fenlei` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '分类',
  `guimo` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '规模',
  `geshou` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '歌手',
  `shijian` datetime NULL DEFAULT NULL COMMENT '时间',
  `chengshi` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '城市',
  `didian` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '地点',
  `xuanchuanpian` varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '宣传片',
  `xiangqing` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '详情',
  `price` float NOT NULL COMMENT '价格',
  `number` int(11) NOT NULL COMMENT '座位总数',
  `selected` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '已选座位[用,号隔开]',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 37 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '演唱会' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of yanchanghui
-- ----------------------------
INSERT INTO `yanchanghui` VALUES (31, '2021-04-24 14:22:42', 'Taylor Swift Reputation 世界演唱会（南宁站）', 'http://localhost:8080/ychpw/upload/yanchanghui_haibao1.jpg', '内娱', '小型', '泰勒·斯威夫特', '2021-04-24 14:22:42', '南宁', '体育中心', 'https://cn-gddg-ct-01-21.bilivideo.com/upgcxcode/33/32/1514203233/1514203233-1-16.mp4?e=ig8euxZM2rNcNbRVhwdVhwdlhWdVhwdVhoNvNC8BqJIzNbfq9rVEuxTEnE8L5F6VnEsSTx0vkX8fqJeYTj_lta53NCM=&uipk=5&nbs=1&deadline=1713924969&gen=playurlv2&os=bcache&oi=17627301&trid=00009b9be3adf0bf4db084a47baf2ae3feach&mid=0&platform=html5&upsig=28b0203d73276780acfb88b58001473e&uparams=e,uipk,nbs,deadline,gen,os,oi,trid,mid,platform&cdnid=61321&bvc=vod&nettype=0&f=h_0_0&bw=55259&logo=80000000', '<div data-v-162a776c=\"\" data-spm=\"detail-info\" class=\"detail\"><div id=\"detail\" class=\"list\"><!----> <div class=\"title\" data-spm-anchor-id=\"a2oeg.project.detail-info.i1.73746420PRLF5T\">演出介绍</div> <div class=\"words\"><p><p style=\"text-align: center;\"><strong>棱镜「多少年·多少面」2024巡回演唱会</strong></p>\r\n<p style=\"text-align: center;\">【北京】预售开启时间：<br>5/17场次：4月8日（周一）中午12:00<br>5/18场次：4月8日（周一）中午12:30</p>\r\n<p style=\"text-align: center;\"><strong><img src=\"//img.alicdn.com/imgextra/i2/2251059038/O1CN01qflDjV2GdSaNFZtpf_!!2251059038.png_q60.jpg\" width=\"1654\" height=\"2339\" damai_width=\"1654\" damai_height=\"2339\" data-spm-anchor-id=\"a2oeg.project.detail-info.i0.73746420PRLF5T\"></strong></p>\r\n<p><img src=\"//img.alicdn.com/imgextra/i3/2251059038/O1CN018dlgFC2GdSaMerIQ3_!!2251059038.jpg_q60.jpg\" width=\"800\" height=\"1284\" damai_width=\"800\" damai_height=\"1284\"></p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n<p><strong>关于「多少年·多少面」演唱会</strong></p>\r\n<p>&nbsp;</p>\r\n<p>多少年，多少面</p>\r\n<p>如果人生是一道数学题的话，答案应该并不复杂。</p>\r\n<p>每个人都可以或多或少推导出自己的人生极限。</p>\r\n<p>但不可预知的是在通往极限的过程中，我们会和哪些人相遇，会经历多少遗憾与欣喜，多少错过与重逢。</p>\r\n<p>所以，无论我和你还拥有多少年，还可以再见面多少次。</p>\r\n<p>我仍坚信，我们还能再次遇见。</p>\r\n<p>&nbsp;</p>\r\n<p>就像《克林》里唱的：“人生是偶然，在自己的路上义无反顾地狂奔吧！”我们都无法预测未来，却也依旧可以如鲸向海，踏浪而行；我们不知还有多少面可以见，但却拥有珍惜当下每一次见面的权利。</p>\r\n<p>所以，见面吧朋友们！</p></p></div></div> <div id=\"notice0\" class=\"list\"><div class=\"title\">购票须知</div> <div class=\"words\"><div><p class=\"item_title\">限购规则</p> <ul><li>每笔订单最多购买4张</li></ul></div><div><p class=\"item_title\">退票/换票规则</p> <ul><li>本项目支持有条件退款，若需要收取退票手续费，将以用户实际支付票款为基准收取。基于项目主办方提供的退票政策不同，具体可支持用户申请退款的情形请详见该项目详情页退票政策相关说明或公告。</li></ul></div><div><p class=\"item_title\">入场规则</p> <ul><li>支持多种票品验票后入场，如证件电子票。</li></ul></div><div><p class=\"item_title\">儿童购票</p> <ul><li>儿童一律凭票入场</li></ul></div><div><p class=\"item_title\">发票说明</p> <ul><li>演出开始前，去【订单详情页】提交发票申请。我们会将电子发票发送至您的邮箱。</li></ul></div><div><p class=\"item_title\">实名购票规则</p> <ul><li>一张门票对应一个证件；证件支持：台湾居民来往大陆通行证/外国人永久居留身份证/港澳台居民居住证/港澳居民来往内地通行证/身份证/护照</li></ul></div><div><p class=\"item_title\">异常排单说明</p> <ul><li>对于异常订购行为，大麦网有权在订单成立或者生效之后取消相应订单。异常订购行为包括但不限于以下情形：\r\n（1）通过同一ID订购超出限购张数的订单。\r\n（2）经合理判断认为非真实消费者的下单行为，包括但不限于通过批量相同或虚构的支付账号、收货地址（包括下单时填写及最终实际收货地址）、收件人、电话号码订购超出限购张数的订单。</li></ul></div><div><p class=\"item_title\">温馨提示</p> <ul><li>1.购买前请您提前规划好行程，做好相应准备，以免影响您的正常观演，感谢您的理解和配合。2.若演出受不可抗力影响延期或取消，大麦将对演出票订单按照项目官方通知方案进行处理，其他因观演发生的费用需由您自行承担。</li></ul></div></div></div><div id=\"notice1\" class=\"list\"><div class=\"title\">观演须知</div> <div class=\"words\"><div><p class=\"item_title\">演出时长</p> <ul><li>约120分钟（以现场为准）</li></ul></div><div><p class=\"item_title\">入场时间</p> <ul><li>请于演出前约120分钟入场</li></ul></div><div><p class=\"item_title\">最低演出曲目</p> <ul><li>20</li></ul></div><div><p class=\"item_title\">主要演员</p> <ul><li>棱镜乐队</li></ul></div><div><p class=\"item_title\">最低演出时长</p> <ul><li>90分钟</li></ul></div><div><p class=\"item_title\">禁止携带物品</p> <ul><li>由于安保和版权的原因，大多数演出、展览及比赛场所禁止携带食品、饮料、专业摄录设备、打火机等物品，请您注意现场工作人员和广播的提示，予以配合</li></ul></div><div><p class=\"item_title\">寄存说明</p> <ul><li data-spm-anchor-id=\"a2oeg.project.detail-info.i2.73746420PRLF5T\">无寄存处,请自行保管携带物品，谨防贵重物品丢失。</li></ul></div><div><p class=\"item_title\">大麦网初始开售时全场可售门票总张数</p> <ul><li>5.17日5333张，5.18日5433张</li></ul></div></div></div></div>', 99.9, 20, '1,3,5,7,9,2,4');
INSERT INTO `yanchanghui` VALUES (32, '2021-04-24 14:22:42', 'G.E.M 邓紫棋 世界巡回演唱会（广州站）', 'http://localhost:8080/ychpw/upload/yanchanghui_haibao2.jpg', '港澳台', '小型', '邓紫棋', '2021-04-24 14:22:42', '广州', '演艺中心', 'https://cn-gddg-ct-01-21.bilivideo.com/upgcxcode/33/32/1514203233/1514203233-1-16.mp4?e=ig8euxZM2rNcNbRVhwdVhwdlhWdVhwdVhoNvNC8BqJIzNbfq9rVEuxTEnE8L5F6VnEsSTx0vkX8fqJeYTj_lta53NCM=&uipk=5&nbs=1&deadline=1713924969&gen=playurlv2&os=bcache&oi=17627301&trid=00009b9be3adf0bf4db084a47baf2ae3feach&mid=0&platform=html5&upsig=28b0203d73276780acfb88b58001473e&uparams=e,uipk,nbs,deadline,gen,os,oi,trid,mid,platform&cdnid=61321&bvc=vod&nettype=0&f=h_0_0&bw=55259&logo=80000000', '<div data-v-162a776c=\"\" data-spm=\"detail-info\" class=\"detail\"><div id=\"detail\" class=\"list\"><!----> <div class=\"title\" data-spm-anchor-id=\"a2oeg.project.detail-info.i1.73746420PRLF5T\">演出介绍</div> <div class=\"words\"><p><p style=\"text-align: center;\"><strong>棱镜「多少年·多少面」2024巡回演唱会</strong></p>\r\n<p style=\"text-align: center;\">【北京】预售开启时间：<br>5/17场次：4月8日（周一）中午12:00<br>5/18场次：4月8日（周一）中午12:30</p>\r\n<p style=\"text-align: center;\"><strong><img src=\"//img.alicdn.com/imgextra/i2/2251059038/O1CN01qflDjV2GdSaNFZtpf_!!2251059038.png_q60.jpg\" width=\"1654\" height=\"2339\" damai_width=\"1654\" damai_height=\"2339\" data-spm-anchor-id=\"a2oeg.project.detail-info.i0.73746420PRLF5T\"></strong></p>\r\n<p><img src=\"//img.alicdn.com/imgextra/i3/2251059038/O1CN018dlgFC2GdSaMerIQ3_!!2251059038.jpg_q60.jpg\" width=\"800\" height=\"1284\" damai_width=\"800\" damai_height=\"1284\"></p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n<p><strong>关于「多少年·多少面」演唱会</strong></p>\r\n<p>&nbsp;</p>\r\n<p>多少年，多少面</p>\r\n<p>如果人生是一道数学题的话，答案应该并不复杂。</p>\r\n<p>每个人都可以或多或少推导出自己的人生极限。</p>\r\n<p>但不可预知的是在通往极限的过程中，我们会和哪些人相遇，会经历多少遗憾与欣喜，多少错过与重逢。</p>\r\n<p>所以，无论我和你还拥有多少年，还可以再见面多少次。</p>\r\n<p>我仍坚信，我们还能再次遇见。</p>\r\n<p>&nbsp;</p>\r\n<p>就像《克林》里唱的：“人生是偶然，在自己的路上义无反顾地狂奔吧！”我们都无法预测未来，却也依旧可以如鲸向海，踏浪而行；我们不知还有多少面可以见，但却拥有珍惜当下每一次见面的权利。</p>\r\n<p>所以，见面吧朋友们！</p></p></div></div> <div id=\"notice0\" class=\"list\"><div class=\"title\">购票须知</div> <div class=\"words\"><div><p class=\"item_title\">限购规则</p> <ul><li>每笔订单最多购买4张</li></ul></div><div><p class=\"item_title\">退票/换票规则</p> <ul><li>本项目支持有条件退款，若需要收取退票手续费，将以用户实际支付票款为基准收取。基于项目主办方提供的退票政策不同，具体可支持用户申请退款的情形请详见该项目详情页退票政策相关说明或公告。</li></ul></div><div><p class=\"item_title\">入场规则</p> <ul><li>支持多种票品验票后入场，如证件电子票。</li></ul></div><div><p class=\"item_title\">儿童购票</p> <ul><li>儿童一律凭票入场</li></ul></div><div><p class=\"item_title\">发票说明</p> <ul><li>演出开始前，去【订单详情页】提交发票申请。我们会将电子发票发送至您的邮箱。</li></ul></div><div><p class=\"item_title\">实名购票规则</p> <ul><li>一张门票对应一个证件；证件支持：台湾居民来往大陆通行证/外国人永久居留身份证/港澳台居民居住证/港澳居民来往内地通行证/身份证/护照</li></ul></div><div><p class=\"item_title\">异常排单说明</p> <ul><li>对于异常订购行为，大麦网有权在订单成立或者生效之后取消相应订单。异常订购行为包括但不限于以下情形：\r\n（1）通过同一ID订购超出限购张数的订单。\r\n（2）经合理判断认为非真实消费者的下单行为，包括但不限于通过批量相同或虚构的支付账号、收货地址（包括下单时填写及最终实际收货地址）、收件人、电话号码订购超出限购张数的订单。</li></ul></div><div><p class=\"item_title\">温馨提示</p> <ul><li>1.购买前请您提前规划好行程，做好相应准备，以免影响您的正常观演，感谢您的理解和配合。2.若演出受不可抗力影响延期或取消，大麦将对演出票订单按照项目官方通知方案进行处理，其他因观演发生的费用需由您自行承担。</li></ul></div></div></div><div id=\"notice1\" class=\"list\"><div class=\"title\">观演须知</div> <div class=\"words\"><div><p class=\"item_title\">演出时长</p> <ul><li>约120分钟（以现场为准）</li></ul></div><div><p class=\"item_title\">入场时间</p> <ul><li>请于演出前约120分钟入场</li></ul></div><div><p class=\"item_title\">最低演出曲目</p> <ul><li>20</li></ul></div><div><p class=\"item_title\">主要演员</p> <ul><li>棱镜乐队</li></ul></div><div><p class=\"item_title\">最低演出时长</p> <ul><li>90分钟</li></ul></div><div><p class=\"item_title\">禁止携带物品</p> <ul><li>由于安保和版权的原因，大多数演出、展览及比赛场所禁止携带食品、饮料、专业摄录设备、打火机等物品，请您注意现场工作人员和广播的提示，予以配合</li></ul></div><div><p class=\"item_title\">寄存说明</p> <ul><li data-spm-anchor-id=\"a2oeg.project.detail-info.i2.73746420PRLF5T\">无寄存处,请自行保管携带物品，谨防贵重物品丢失。</li></ul></div><div><p class=\"item_title\">大麦网初始开售时全场可售门票总张数</p> <ul><li>5.17日5333张，5.18日5433张</li></ul></div></div></div></div>', 99.9, 20, '1,3,5,7,9,2,4,6,8,10,20,11,12');
INSERT INTO `yanchanghui` VALUES (33, '2021-04-24 14:22:42', '张靓颖和他的朋友们音乐会', 'http://localhost:8080/ychpw/upload/yanchanghui_haibao3.jpg', '日本', '小型', '张靓颖', '2021-04-24 14:22:42', '南宁', '体育中心', 'https://cn-gddg-ct-01-21.bilivideo.com/upgcxcode/33/32/1514203233/1514203233-1-16.mp4?e=ig8euxZM2rNcNbRVhwdVhwdlhWdVhwdVhoNvNC8BqJIzNbfq9rVEuxTEnE8L5F6VnEsSTx0vkX8fqJeYTj_lta53NCM=&uipk=5&nbs=1&deadline=1713924969&gen=playurlv2&os=bcache&oi=17627301&trid=00009b9be3adf0bf4db084a47baf2ae3feach&mid=0&platform=html5&upsig=28b0203d73276780acfb88b58001473e&uparams=e,uipk,nbs,deadline,gen,os,oi,trid,mid,platform&cdnid=61321&bvc=vod&nettype=0&f=h_0_0&bw=55259&logo=80000000', '<div data-v-162a776c=\"\" data-spm=\"detail-info\" class=\"detail\"><div id=\"detail\" class=\"list\"><!----> <div class=\"title\" data-spm-anchor-id=\"a2oeg.project.detail-info.i1.73746420PRLF5T\">演出介绍</div> <div class=\"words\"><p><p style=\"text-align: center;\"><strong>棱镜「多少年·多少面」2024巡回演唱会</strong></p>\r\n<p style=\"text-align: center;\">【北京】预售开启时间：<br>5/17场次：4月8日（周一）中午12:00<br>5/18场次：4月8日（周一）中午12:30</p>\r\n<p style=\"text-align: center;\"><strong><img src=\"//img.alicdn.com/imgextra/i2/2251059038/O1CN01qflDjV2GdSaNFZtpf_!!2251059038.png_q60.jpg\" width=\"1654\" height=\"2339\" damai_width=\"1654\" damai_height=\"2339\" data-spm-anchor-id=\"a2oeg.project.detail-info.i0.73746420PRLF5T\"></strong></p>\r\n<p><img src=\"//img.alicdn.com/imgextra/i3/2251059038/O1CN018dlgFC2GdSaMerIQ3_!!2251059038.jpg_q60.jpg\" width=\"800\" height=\"1284\" damai_width=\"800\" damai_height=\"1284\"></p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n<p><strong>关于「多少年·多少面」演唱会</strong></p>\r\n<p>&nbsp;</p>\r\n<p>多少年，多少面</p>\r\n<p>如果人生是一道数学题的话，答案应该并不复杂。</p>\r\n<p>每个人都可以或多或少推导出自己的人生极限。</p>\r\n<p>但不可预知的是在通往极限的过程中，我们会和哪些人相遇，会经历多少遗憾与欣喜，多少错过与重逢。</p>\r\n<p>所以，无论我和你还拥有多少年，还可以再见面多少次。</p>\r\n<p>我仍坚信，我们还能再次遇见。</p>\r\n<p>&nbsp;</p>\r\n<p>就像《克林》里唱的：“人生是偶然，在自己的路上义无反顾地狂奔吧！”我们都无法预测未来，却也依旧可以如鲸向海，踏浪而行；我们不知还有多少面可以见，但却拥有珍惜当下每一次见面的权利。</p>\r\n<p>所以，见面吧朋友们！</p></p></div></div> <div id=\"notice0\" class=\"list\"><div class=\"title\">购票须知</div> <div class=\"words\"><div><p class=\"item_title\">限购规则</p> <ul><li>每笔订单最多购买4张</li></ul></div><div><p class=\"item_title\">退票/换票规则</p> <ul><li>本项目支持有条件退款，若需要收取退票手续费，将以用户实际支付票款为基准收取。基于项目主办方提供的退票政策不同，具体可支持用户申请退款的情形请详见该项目详情页退票政策相关说明或公告。</li></ul></div><div><p class=\"item_title\">入场规则</p> <ul><li>支持多种票品验票后入场，如证件电子票。</li></ul></div><div><p class=\"item_title\">儿童购票</p> <ul><li>儿童一律凭票入场</li></ul></div><div><p class=\"item_title\">发票说明</p> <ul><li>演出开始前，去【订单详情页】提交发票申请。我们会将电子发票发送至您的邮箱。</li></ul></div><div><p class=\"item_title\">实名购票规则</p> <ul><li>一张门票对应一个证件；证件支持：台湾居民来往大陆通行证/外国人永久居留身份证/港澳台居民居住证/港澳居民来往内地通行证/身份证/护照</li></ul></div><div><p class=\"item_title\">异常排单说明</p> <ul><li>对于异常订购行为，大麦网有权在订单成立或者生效之后取消相应订单。异常订购行为包括但不限于以下情形：\r\n（1）通过同一ID订购超出限购张数的订单。\r\n（2）经合理判断认为非真实消费者的下单行为，包括但不限于通过批量相同或虚构的支付账号、收货地址（包括下单时填写及最终实际收货地址）、收件人、电话号码订购超出限购张数的订单。</li></ul></div><div><p class=\"item_title\">温馨提示</p> <ul><li>1.购买前请您提前规划好行程，做好相应准备，以免影响您的正常观演，感谢您的理解和配合。2.若演出受不可抗力影响延期或取消，大麦将对演出票订单按照项目官方通知方案进行处理，其他因观演发生的费用需由您自行承担。</li></ul></div></div></div><div id=\"notice1\" class=\"list\"><div class=\"title\">观演须知</div> <div class=\"words\"><div><p class=\"item_title\">演出时长</p> <ul><li>约120分钟（以现场为准）</li></ul></div><div><p class=\"item_title\">入场时间</p> <ul><li>请于演出前约120分钟入场</li></ul></div><div><p class=\"item_title\">最低演出曲目</p> <ul><li>20</li></ul></div><div><p class=\"item_title\">主要演员</p> <ul><li>棱镜乐队</li></ul></div><div><p class=\"item_title\">最低演出时长</p> <ul><li>90分钟</li></ul></div><div><p class=\"item_title\">禁止携带物品</p> <ul><li>由于安保和版权的原因，大多数演出、展览及比赛场所禁止携带食品、饮料、专业摄录设备、打火机等物品，请您注意现场工作人员和广播的提示，予以配合</li></ul></div><div><p class=\"item_title\">寄存说明</p> <ul><li data-spm-anchor-id=\"a2oeg.project.detail-info.i2.73746420PRLF5T\">无寄存处,请自行保管携带物品，谨防贵重物品丢失。</li></ul></div><div><p class=\"item_title\">大麦网初始开售时全场可售门票总张数</p> <ul><li>5.17日5333张，5.18日5433张</li></ul></div></div></div></div>', 99.9, 20, '1,3,5,7,9');
INSERT INTO `yanchanghui` VALUES (34, '2021-04-24 14:22:42', '华晨宇火星演唱会北京站', 'http://localhost:8080/ychpw/upload/yanchanghui_haibao4.jpg', '欧洲', '小型', '华晨宇', '2021-04-24 14:22:42', '北京', '生态中心', 'https://cn-gddg-ct-01-21.bilivideo.com/upgcxcode/33/32/1514203233/1514203233-1-16.mp4?e=ig8euxZM2rNcNbRVhwdVhwdlhWdVhwdVhoNvNC8BqJIzNbfq9rVEuxTEnE8L5F6VnEsSTx0vkX8fqJeYTj_lta53NCM=&uipk=5&nbs=1&deadline=1713924969&gen=playurlv2&os=bcache&oi=17627301&trid=00009b9be3adf0bf4db084a47baf2ae3feach&mid=0&platform=html5&upsig=28b0203d73276780acfb88b58001473e&uparams=e,uipk,nbs,deadline,gen,os,oi,trid,mid,platform&cdnid=61321&bvc=vod&nettype=0&f=h_0_0&bw=55259&logo=80000000', '<div data-v-162a776c=\"\" data-spm=\"detail-info\" class=\"detail\"><div id=\"detail\" class=\"list\"><!----> <div class=\"title\" data-spm-anchor-id=\"a2oeg.project.detail-info.i1.73746420PRLF5T\">演出介绍</div> <div class=\"words\"><p><p style=\"text-align: center;\"><strong>棱镜「多少年·多少面」2024巡回演唱会</strong></p>\r\n<p style=\"text-align: center;\">【北京】预售开启时间：<br>5/17场次：4月8日（周一）中午12:00<br>5/18场次：4月8日（周一）中午12:30</p>\r\n<p style=\"text-align: center;\"><strong><img src=\"//img.alicdn.com/imgextra/i2/2251059038/O1CN01qflDjV2GdSaNFZtpf_!!2251059038.png_q60.jpg\" width=\"1654\" height=\"2339\" damai_width=\"1654\" damai_height=\"2339\" data-spm-anchor-id=\"a2oeg.project.detail-info.i0.73746420PRLF5T\"></strong></p>\r\n<p><img src=\"//img.alicdn.com/imgextra/i3/2251059038/O1CN018dlgFC2GdSaMerIQ3_!!2251059038.jpg_q60.jpg\" width=\"800\" height=\"1284\" damai_width=\"800\" damai_height=\"1284\"></p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n<p><strong>关于「多少年·多少面」演唱会</strong></p>\r\n<p>&nbsp;</p>\r\n<p>多少年，多少面</p>\r\n<p>如果人生是一道数学题的话，答案应该并不复杂。</p>\r\n<p>每个人都可以或多或少推导出自己的人生极限。</p>\r\n<p>但不可预知的是在通往极限的过程中，我们会和哪些人相遇，会经历多少遗憾与欣喜，多少错过与重逢。</p>\r\n<p>所以，无论我和你还拥有多少年，还可以再见面多少次。</p>\r\n<p>我仍坚信，我们还能再次遇见。</p>\r\n<p>&nbsp;</p>\r\n<p>就像《克林》里唱的：“人生是偶然，在自己的路上义无反顾地狂奔吧！”我们都无法预测未来，却也依旧可以如鲸向海，踏浪而行；我们不知还有多少面可以见，但却拥有珍惜当下每一次见面的权利。</p>\r\n<p>所以，见面吧朋友们！</p></p></div></div> <div id=\"notice0\" class=\"list\"><div class=\"title\">购票须知</div> <div class=\"words\"><div><p class=\"item_title\">限购规则</p> <ul><li>每笔订单最多购买4张</li></ul></div><div><p class=\"item_title\">退票/换票规则</p> <ul><li>本项目支持有条件退款，若需要收取退票手续费，将以用户实际支付票款为基准收取。基于项目主办方提供的退票政策不同，具体可支持用户申请退款的情形请详见该项目详情页退票政策相关说明或公告。</li></ul></div><div><p class=\"item_title\">入场规则</p> <ul><li>支持多种票品验票后入场，如证件电子票。</li></ul></div><div><p class=\"item_title\">儿童购票</p> <ul><li>儿童一律凭票入场</li></ul></div><div><p class=\"item_title\">发票说明</p> <ul><li>演出开始前，去【订单详情页】提交发票申请。我们会将电子发票发送至您的邮箱。</li></ul></div><div><p class=\"item_title\">实名购票规则</p> <ul><li>一张门票对应一个证件；证件支持：台湾居民来往大陆通行证/外国人永久居留身份证/港澳台居民居住证/港澳居民来往内地通行证/身份证/护照</li></ul></div><div><p class=\"item_title\">异常排单说明</p> <ul><li>对于异常订购行为，大麦网有权在订单成立或者生效之后取消相应订单。异常订购行为包括但不限于以下情形：\r\n（1）通过同一ID订购超出限购张数的订单。\r\n（2）经合理判断认为非真实消费者的下单行为，包括但不限于通过批量相同或虚构的支付账号、收货地址（包括下单时填写及最终实际收货地址）、收件人、电话号码订购超出限购张数的订单。</li></ul></div><div><p class=\"item_title\">温馨提示</p> <ul><li>1.购买前请您提前规划好行程，做好相应准备，以免影响您的正常观演，感谢您的理解和配合。2.若演出受不可抗力影响延期或取消，大麦将对演出票订单按照项目官方通知方案进行处理，其他因观演发生的费用需由您自行承担。</li></ul></div></div></div><div id=\"notice1\" class=\"list\"><div class=\"title\">观演须知</div> <div class=\"words\"><div><p class=\"item_title\">演出时长</p> <ul><li>约120分钟（以现场为准）</li></ul></div><div><p class=\"item_title\">入场时间</p> <ul><li>请于演出前约120分钟入场</li></ul></div><div><p class=\"item_title\">最低演出曲目</p> <ul><li>20</li></ul></div><div><p class=\"item_title\">主要演员</p> <ul><li>棱镜乐队</li></ul></div><div><p class=\"item_title\">最低演出时长</p> <ul><li>90分钟</li></ul></div><div><p class=\"item_title\">禁止携带物品</p> <ul><li>由于安保和版权的原因，大多数演出、展览及比赛场所禁止携带食品、饮料、专业摄录设备、打火机等物品，请您注意现场工作人员和广播的提示，予以配合</li></ul></div><div><p class=\"item_title\">寄存说明</p> <ul><li data-spm-anchor-id=\"a2oeg.project.detail-info.i2.73746420PRLF5T\">无寄存处,请自行保管携带物品，谨防贵重物品丢失。</li></ul></div><div><p class=\"item_title\">大麦网初始开售时全场可售门票总张数</p> <ul><li>5.17日5333张，5.18日5433张</li></ul></div></div></div></div>', 99.9, 20, '1,3,5,7,9');
INSERT INTO `yanchanghui` VALUES (35, '2021-04-24 14:22:42', '张学友世纪演唱会（南宁站）', 'http://localhost:8080/ychpw/upload/yanchanghui_haibao5.jpg', '美国', '小型', '张学友', '2021-04-24 14:22:42', '南宁', '体育中心', 'https://cn-gddg-ct-01-21.bilivideo.com/upgcxcode/33/32/1514203233/1514203233-1-16.mp4?e=ig8euxZM2rNcNbRVhwdVhwdlhWdVhwdVhoNvNC8BqJIzNbfq9rVEuxTEnE8L5F6VnEsSTx0vkX8fqJeYTj_lta53NCM=&uipk=5&nbs=1&deadline=1713924969&gen=playurlv2&os=bcache&oi=17627301&trid=00009b9be3adf0bf4db084a47baf2ae3feach&mid=0&platform=html5&upsig=28b0203d73276780acfb88b58001473e&uparams=e,uipk,nbs,deadline,gen,os,oi,trid,mid,platform&cdnid=61321&bvc=vod&nettype=0&f=h_0_0&bw=55259&logo=80000000', '<div data-v-162a776c=\"\" data-spm=\"detail-info\" class=\"detail\"><div id=\"detail\" class=\"list\"><!----> <div class=\"title\" data-spm-anchor-id=\"a2oeg.project.detail-info.i1.73746420PRLF5T\">演出介绍</div> <div class=\"words\"><p><p style=\"text-align: center;\"><strong>棱镜「多少年·多少面」2024巡回演唱会</strong></p>\r\n<p style=\"text-align: center;\">【北京】预售开启时间：<br>5/17场次：4月8日（周一）中午12:00<br>5/18场次：4月8日（周一）中午12:30</p>\r\n<p style=\"text-align: center;\"><strong><img src=\"//img.alicdn.com/imgextra/i2/2251059038/O1CN01qflDjV2GdSaNFZtpf_!!2251059038.png_q60.jpg\" width=\"1654\" height=\"2339\" damai_width=\"1654\" damai_height=\"2339\" data-spm-anchor-id=\"a2oeg.project.detail-info.i0.73746420PRLF5T\"></strong></p>\r\n<p><img src=\"//img.alicdn.com/imgextra/i3/2251059038/O1CN018dlgFC2GdSaMerIQ3_!!2251059038.jpg_q60.jpg\" width=\"800\" height=\"1284\" damai_width=\"800\" damai_height=\"1284\"></p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n<p><strong>关于「多少年·多少面」演唱会</strong></p>\r\n<p>&nbsp;</p>\r\n<p>多少年，多少面</p>\r\n<p>如果人生是一道数学题的话，答案应该并不复杂。</p>\r\n<p>每个人都可以或多或少推导出自己的人生极限。</p>\r\n<p>但不可预知的是在通往极限的过程中，我们会和哪些人相遇，会经历多少遗憾与欣喜，多少错过与重逢。</p>\r\n<p>所以，无论我和你还拥有多少年，还可以再见面多少次。</p>\r\n<p>我仍坚信，我们还能再次遇见。</p>\r\n<p>&nbsp;</p>\r\n<p>就像《克林》里唱的：“人生是偶然，在自己的路上义无反顾地狂奔吧！”我们都无法预测未来，却也依旧可以如鲸向海，踏浪而行；我们不知还有多少面可以见，但却拥有珍惜当下每一次见面的权利。</p>\r\n<p>所以，见面吧朋友们！</p></p></div></div> <div id=\"notice0\" class=\"list\"><div class=\"title\">购票须知</div> <div class=\"words\"><div><p class=\"item_title\">限购规则</p> <ul><li>每笔订单最多购买4张</li></ul></div><div><p class=\"item_title\">退票/换票规则</p> <ul><li>本项目支持有条件退款，若需要收取退票手续费，将以用户实际支付票款为基准收取。基于项目主办方提供的退票政策不同，具体可支持用户申请退款的情形请详见该项目详情页退票政策相关说明或公告。</li></ul></div><div><p class=\"item_title\">入场规则</p> <ul><li>支持多种票品验票后入场，如证件电子票。</li></ul></div><div><p class=\"item_title\">儿童购票</p> <ul><li>儿童一律凭票入场</li></ul></div><div><p class=\"item_title\">发票说明</p> <ul><li>演出开始前，去【订单详情页】提交发票申请。我们会将电子发票发送至您的邮箱。</li></ul></div><div><p class=\"item_title\">实名购票规则</p> <ul><li>一张门票对应一个证件；证件支持：台湾居民来往大陆通行证/外国人永久居留身份证/港澳台居民居住证/港澳居民来往内地通行证/身份证/护照</li></ul></div><div><p class=\"item_title\">异常排单说明</p> <ul><li>对于异常订购行为，大麦网有权在订单成立或者生效之后取消相应订单。异常订购行为包括但不限于以下情形：\r\n（1）通过同一ID订购超出限购张数的订单。\r\n（2）经合理判断认为非真实消费者的下单行为，包括但不限于通过批量相同或虚构的支付账号、收货地址（包括下单时填写及最终实际收货地址）、收件人、电话号码订购超出限购张数的订单。</li></ul></div><div><p class=\"item_title\">温馨提示</p> <ul><li>1.购买前请您提前规划好行程，做好相应准备，以免影响您的正常观演，感谢您的理解和配合。2.若演出受不可抗力影响延期或取消，大麦将对演出票订单按照项目官方通知方案进行处理，其他因观演发生的费用需由您自行承担。</li></ul></div></div></div><div id=\"notice1\" class=\"list\"><div class=\"title\">观演须知</div> <div class=\"words\"><div><p class=\"item_title\">演出时长</p> <ul><li>约120分钟（以现场为准）</li></ul></div><div><p class=\"item_title\">入场时间</p> <ul><li>请于演出前约120分钟入场</li></ul></div><div><p class=\"item_title\">最低演出曲目</p> <ul><li>20</li></ul></div><div><p class=\"item_title\">主要演员</p> <ul><li>棱镜乐队</li></ul></div><div><p class=\"item_title\">最低演出时长</p> <ul><li>90分钟</li></ul></div><div><p class=\"item_title\">禁止携带物品</p> <ul><li>由于安保和版权的原因，大多数演出、展览及比赛场所禁止携带食品、饮料、专业摄录设备、打火机等物品，请您注意现场工作人员和广播的提示，予以配合</li></ul></div><div><p class=\"item_title\">寄存说明</p> <ul><li data-spm-anchor-id=\"a2oeg.project.detail-info.i2.73746420PRLF5T\">无寄存处,请自行保管携带物品，谨防贵重物品丢失。</li></ul></div><div><p class=\"item_title\">大麦网初始开售时全场可售门票总张数</p> <ul><li>5.17日5333张，5.18日5433张</li></ul></div></div></div></div>', 99.9, 20, '1,3,5,7,9');
INSERT INTO `yanchanghui` VALUES (36, '2021-04-24 14:22:42', '刘德华世界巡回演唱会南宁站', 'http://localhost:8080/ychpw/upload/yanchanghui_haibao6.jpg', '拉美', '小型', '刘德华', '2021-04-24 14:22:42', '南宁', '体育中心', 'https://cn-gddg-ct-01-21.bilivideo.com/upgcxcode/33/32/1514203233/1514203233-1-16.mp4?e=ig8euxZM2rNcNbRVhwdVhwdlhWdVhwdVhoNvNC8BqJIzNbfq9rVEuxTEnE8L5F6VnEsSTx0vkX8fqJeYTj_lta53NCM=&uipk=5&nbs=1&deadline=1713924969&gen=playurlv2&os=bcache&oi=17627301&trid=00009b9be3adf0bf4db084a47baf2ae3feach&mid=0&platform=html5&upsig=28b0203d73276780acfb88b58001473e&uparams=e,uipk,nbs,deadline,gen,os,oi,trid,mid,platform&cdnid=61321&bvc=vod&nettype=0&f=h_0_0&bw=55259&logo=80000000', '<div data-v-162a776c=\"\" data-spm=\"detail-info\" class=\"detail\"><div id=\"detail\" class=\"list\"><!----> <div class=\"title\" data-spm-anchor-id=\"a2oeg.project.detail-info.i1.73746420PRLF5T\">演出介绍</div> <div class=\"words\"><p><p style=\"text-align: center;\"><strong>棱镜「多少年·多少面」2024巡回演唱会</strong></p>\r\n<p style=\"text-align: center;\">【北京】预售开启时间：<br>5/17场次：4月8日（周一）中午12:00<br>5/18场次：4月8日（周一）中午12:30</p>\r\n<p style=\"text-align: center;\"><strong><img src=\"//img.alicdn.com/imgextra/i2/2251059038/O1CN01qflDjV2GdSaNFZtpf_!!2251059038.png_q60.jpg\" width=\"1654\" height=\"2339\" damai_width=\"1654\" damai_height=\"2339\" data-spm-anchor-id=\"a2oeg.project.detail-info.i0.73746420PRLF5T\"></strong></p>\r\n<p><img src=\"//img.alicdn.com/imgextra/i3/2251059038/O1CN018dlgFC2GdSaMerIQ3_!!2251059038.jpg_q60.jpg\" width=\"800\" height=\"1284\" damai_width=\"800\" damai_height=\"1284\"></p>\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n<p><strong>关于「多少年·多少面」演唱会</strong></p>\r\n<p>&nbsp;</p>\r\n<p>多少年，多少面</p>\r\n<p>如果人生是一道数学题的话，答案应该并不复杂。</p>\r\n<p>每个人都可以或多或少推导出自己的人生极限。</p>\r\n<p>但不可预知的是在通往极限的过程中，我们会和哪些人相遇，会经历多少遗憾与欣喜，多少错过与重逢。</p>\r\n<p>所以，无论我和你还拥有多少年，还可以再见面多少次。</p>\r\n<p>我仍坚信，我们还能再次遇见。</p>\r\n<p>&nbsp;</p>\r\n<p>就像《克林》里唱的：“人生是偶然，在自己的路上义无反顾地狂奔吧！”我们都无法预测未来，却也依旧可以如鲸向海，踏浪而行；我们不知还有多少面可以见，但却拥有珍惜当下每一次见面的权利。</p>\r\n<p>所以，见面吧朋友们！</p></p></div></div> <div id=\"notice0\" class=\"list\"><div class=\"title\">购票须知</div> <div class=\"words\"><div><p class=\"item_title\">限购规则</p> <ul><li>每笔订单最多购买4张</li></ul></div><div><p class=\"item_title\">退票/换票规则</p> <ul><li>本项目支持有条件退款，若需要收取退票手续费，将以用户实际支付票款为基准收取。基于项目主办方提供的退票政策不同，具体可支持用户申请退款的情形请详见该项目详情页退票政策相关说明或公告。</li></ul></div><div><p class=\"item_title\">入场规则</p> <ul><li>支持多种票品验票后入场，如证件电子票。</li></ul></div><div><p class=\"item_title\">儿童购票</p> <ul><li>儿童一律凭票入场</li></ul></div><div><p class=\"item_title\">发票说明</p> <ul><li>演出开始前，去【订单详情页】提交发票申请。我们会将电子发票发送至您的邮箱。</li></ul></div><div><p class=\"item_title\">实名购票规则</p> <ul><li>一张门票对应一个证件；证件支持：台湾居民来往大陆通行证/外国人永久居留身份证/港澳台居民居住证/港澳居民来往内地通行证/身份证/护照</li></ul></div><div><p class=\"item_title\">异常排单说明</p> <ul><li>对于异常订购行为，大麦网有权在订单成立或者生效之后取消相应订单。异常订购行为包括但不限于以下情形：\r\n（1）通过同一ID订购超出限购张数的订单。\r\n（2）经合理判断认为非真实消费者的下单行为，包括但不限于通过批量相同或虚构的支付账号、收货地址（包括下单时填写及最终实际收货地址）、收件人、电话号码订购超出限购张数的订单。</li></ul></div><div><p class=\"item_title\">温馨提示</p> <ul><li>1.购买前请您提前规划好行程，做好相应准备，以免影响您的正常观演，感谢您的理解和配合。2.若演出受不可抗力影响延期或取消，大麦将对演出票订单按照项目官方通知方案进行处理，其他因观演发生的费用需由您自行承担。</li></ul></div></div></div><div id=\"notice1\" class=\"list\"><div class=\"title\">观演须知</div> <div class=\"words\"><div><p class=\"item_title\">演出时长</p> <ul><li>约120分钟（以现场为准）</li></ul></div><div><p class=\"item_title\">入场时间</p> <ul><li>请于演出前约120分钟入场</li></ul></div><div><p class=\"item_title\">最低演出曲目</p> <ul><li>20</li></ul></div><div><p class=\"item_title\">主要演员</p> <ul><li>棱镜乐队</li></ul></div><div><p class=\"item_title\">最低演出时长</p> <ul><li>90分钟</li></ul></div><div><p class=\"item_title\">禁止携带物品</p> <ul><li>由于安保和版权的原因，大多数演出、展览及比赛场所禁止携带食品、饮料、专业摄录设备、打火机等物品，请您注意现场工作人员和广播的提示，予以配合</li></ul></div><div><p class=\"item_title\">寄存说明</p> <ul><li data-spm-anchor-id=\"a2oeg.project.detail-info.i2.73746420PRLF5T\">无寄存处,请自行保管携带物品，谨防贵重物品丢失。</li></ul></div><div><p class=\"item_title\">大麦网初始开售时全场可售门票总张数</p> <ul><li>5.17日5333张，5.18日5433张</li></ul></div></div></div></div>', 99.9, 20, '1,3,5,7,9');

-- ----------------------------
-- Table structure for yonghu
-- ----------------------------
DROP TABLE IF EXISTS `yonghu`;
CREATE TABLE `yonghu`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `yonghuming` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户名',
  `mima` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '密码',
  `yonghuxingming` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户姓名',
  `touxiang` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '头像',
  `xingbie` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '性别',
  `nianling` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '年龄',
  `shoujihaoma` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '手机号码',
  `youxiang` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '邮箱',
  `money` float NULL DEFAULT 0 COMMENT '余额',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `yonghuming`(`yonghuming`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1713919501795 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of yonghu
-- ----------------------------
INSERT INTO `yonghu` VALUES (1713919501794, '2024-04-24 08:45:01', 'oyo775881', '215405880', '哈哈哈', 'http://localhost:8080/ychpw/upload/1713920394673.jpg', '', '24', '15207719999', '10000@qq.com', 19800.2);

SET FOREIGN_KEY_CHECKS = 1;
